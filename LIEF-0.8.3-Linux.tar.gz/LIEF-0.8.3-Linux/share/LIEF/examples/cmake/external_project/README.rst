LIEF CMake Integration Example - ExternalProject
================================================


.. code-block:: console

  $ mkdir build
  $ cd build
  $ cmake ..
  $ make
  $ HelloLIEF /bin/ls # or explorer.exe or what ever

